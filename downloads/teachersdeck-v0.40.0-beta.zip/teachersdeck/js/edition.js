/*! TeachersDeck v0.40.0 · build 02bf705e91 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TeachersDeck",version:"0.40.0",uni:!1});
