/*! TinyParentDeck v0.8.0 · build 0098976f0f · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TinyParentDeck",version:"0.8.0",uni:!1,kinder:!0,officialIds:["jchohfpfmfkcbofccdgjoakcjpcbnkae"]});
