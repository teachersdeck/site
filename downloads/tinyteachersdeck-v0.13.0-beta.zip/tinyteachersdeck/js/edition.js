/*! TinyTeachersDeck v0.13.0 · build 9cd3a28260 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TinyTeachersDeck",version:"0.13.0",uni:!1,kinder:!0,officialIds:["gpefhecchiadgmfkgokghmlpaloggedb"]});
