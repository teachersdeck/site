/*! ParentDeck v0.27.1 · build 53ab99eea0 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"ParentDeck",version:"0.27.1",uni:!1});
