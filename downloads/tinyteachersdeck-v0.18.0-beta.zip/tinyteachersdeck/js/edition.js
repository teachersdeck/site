/*! TinyTeachersDeck v0.18.0 · build 3397abf71c · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TinyTeachersDeck",version:"0.18.0",uni:!1,kinder:!0,store:!0,officialIds:["gpefhecchiadgmfkgokghmlpaloggedb"]});
