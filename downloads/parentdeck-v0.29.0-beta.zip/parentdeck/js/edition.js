/*! ParentDeck v0.29.0 · build 88b4f11c4d · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"ParentDeck",version:"0.29.0",uni:!1});
