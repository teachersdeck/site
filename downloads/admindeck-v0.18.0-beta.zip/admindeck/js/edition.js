/*! AdminDeck v0.18.0 · build fbf004a156 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"AdminDeck",version:"0.18.0",uni:!1});
