/*! TeachersDeck v0.38.0 · build 7fbc74cebd · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
window.GOOGLE_CONFIG=Object.assign({extensionClientId:"",webClientId:""},window.GOOGLE_CONFIG||{});
