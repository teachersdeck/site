/*! ParentDeck v0.27.0 · build 1fc8f35ecc · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"ParentDeck",version:"0.27.0",uni:!1});
