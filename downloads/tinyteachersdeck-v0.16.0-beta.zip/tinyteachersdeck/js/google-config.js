/*! TinyTeachersDeck v0.16.0 · build 4c3e8299c2 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
window.GOOGLE_CONFIG=Object.assign({extensionClientId:"",webClientId:""},window.GOOGLE_CONFIG||{});
