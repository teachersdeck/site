/*! TeachersDeck v0.39.0 · build 6dec9d1afe · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TeachersDeck",version:"0.39.0",uni:!1});
