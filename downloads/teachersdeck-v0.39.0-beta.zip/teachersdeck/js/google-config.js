/*! TeachersDeck v0.39.0 · build 6dec9d1afe · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
window.GOOGLE_CONFIG=Object.assign({extensionClientId:"",webClientId:""},window.GOOGLE_CONFIG||{});
