/*! TinyParentDeck v0.7.1 · build 8d8b46c191 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TinyParentDeck",version:"0.7.1",uni:!1,kinder:!0,officialIds:["jchohfpfmfkcbofccdgjoakcjpcbnkae"]});
