/*! TeachersDeck v0.34.1 · build e156a8f68d · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TeachersDeck",version:"0.34.1",uni:!1});
