/*! StudentDeck v0.23.1 · build d08f9e96b4 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.SD_EDITION=Object.freeze({name:"StudentDeck",version:"0.23.1",uni:!1,xpOn:!0,setXp(){}});
