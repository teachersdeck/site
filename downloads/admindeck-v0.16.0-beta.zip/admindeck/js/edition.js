/*! AdminDeck v0.16.0 · build f66d9402f3 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"AdminDeck",version:"0.16.0",uni:!1});
