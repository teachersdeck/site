/*! TinyTeachersDeck v0.14.0 · build 5a8f7db377 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TinyTeachersDeck",version:"0.14.0",uni:!1,kinder:!0,officialIds:["gpefhecchiadgmfkgokghmlpaloggedb"]});
