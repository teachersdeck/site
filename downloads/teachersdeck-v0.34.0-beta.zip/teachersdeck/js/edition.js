/*! TeachersDeck v0.34.0 · build b30e3c8ada · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TeachersDeck",version:"0.34.0",uni:!1});
