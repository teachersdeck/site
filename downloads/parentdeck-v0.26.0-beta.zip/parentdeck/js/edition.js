/*! ParentDeck v0.26.0 · build b0020c88b3 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"ParentDeck",version:"0.26.0",uni:!1});
