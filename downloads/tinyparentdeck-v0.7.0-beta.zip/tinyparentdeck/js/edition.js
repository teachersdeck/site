/*! TinyParentDeck v0.7.0 · build 8caa9f9ace · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TinyParentDeck",version:"0.7.0",uni:!1,kinder:!0,officialIds:["jchohfpfmfkcbofccdgjoakcjpcbnkae"]});
