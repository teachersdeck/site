/*! ParentDeck v0.26.1 · build f57ac91978 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"ParentDeck",version:"0.26.1",uni:!1});
