/*! StudentDeck v0.24.0 · build 99e2f5ba05 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.SD_EDITION=Object.freeze({name:"StudentDeck",version:"0.24.0",uni:!1,xpOn:!0,setXp(){}});
