/*! TeachersDeck v0.45.0 · build 2fbc0df85e · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.DECK_EDITION=Object.freeze({name:"TeachersDeck",version:"0.45.0",uni:!1});
