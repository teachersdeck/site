/*! TinyTeachersDeck v0.14.1 · build ca19071d28 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
window.GOOGLE_CONFIG=Object.assign({extensionClientId:"",webClientId:""},window.GOOGLE_CONFIG||{});
