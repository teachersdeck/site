/*! StudentDeck v0.27.0 · build b18af88a16 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.SD_EDITION=Object.freeze({name:"StudentDeck",version:"0.27.0",uni:!1,xpOn:!0,setXp(){}});
