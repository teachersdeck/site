/*! StudentDeck v0.23.0 · build afde255772 · © 2026 TeachersDeck. All rights reserved. Licensed, not sold: see LICENSE.txt. Unauthorised copying or redistribution is prohibited. */
"use strict";window.SD_EDITION=Object.freeze({name:"StudentDeck",version:"0.23.0",uni:!1,xpOn:!0,setXp(){}});
